package com.bnpparibas.bp2s.javatraining;

/**
 * @ Hello world!
 *
 */
public class MyFirstJavaClass {
  public static void main(String[] args) {
    System.out.println("The good old Hello World!");
  }
}
