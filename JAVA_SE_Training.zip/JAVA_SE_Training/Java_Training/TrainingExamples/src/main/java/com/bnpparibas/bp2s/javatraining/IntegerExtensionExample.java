package com.bnpparibas.bp2s.javatraining;

public class IntegerExtensionExample {
  public static void main(String[] args) {
    IntegerExtension a = new NewIntegerExtension("11");
    System.out.println(a.isNegative());

    IntegerExtension a1 = new NewIntegerExtension("11");
    System.out.println(a1.isNegative());
    a1.isNegative();

    IntegerExtension a2 = new NewIntegerExtension("11");
    System.out.println(a2.isNegative());
    System.out.println(a2.isPositive());

  }
}
