package com.bnpparibas.bp2s.javatraining;

public class NewIntegerExtension extends IntegerExtension {

  public NewIntegerExtension(String value) {
    super(value);
  }

  public boolean isNegative() {
    return false;
  }

  public boolean isPositive() {
    return true;
  }
}
