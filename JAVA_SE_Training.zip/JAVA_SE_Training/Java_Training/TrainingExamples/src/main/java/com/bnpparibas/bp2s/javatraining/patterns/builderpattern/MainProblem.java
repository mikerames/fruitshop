package com.bnpparibas.bp2s.javatraining.patterns.builderpattern;


public class MainProblem {

  public static void main(String args[]) {
    EmailMessageProblem email = new EmailMessageProblem("trainer@example.com", "trainee@crisp.se", "hello dear trainee", "email content");
    // this is quite problematic and error prone...
  }
}
