package com.bnpparibas.bp2s.javatraining.concretestatic;


public class Test {
  public static void main(String[] args) {
    Shape[] shapes = {new Circle(10), new Rectangle(5, 10), new Square(10)};
    System.out.println("Sum of areas: " + Shape.sumAreas(shapes));
  }
}
