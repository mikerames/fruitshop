package com.bnpparibas.bp2s.javatraining;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public abstract class DemoTest implements Demoable {

  private static final int CONSTANT_ATTRIBUTE = 0;

  private String firstName;
  private static String lastName;

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public void countMethod(int iterations) {
    if (iterations > 0) {
      for (int iterationNumber = 0; iterationNumber < iterations; iterationNumber++) {
        System.out.println("Iteration Number" + iterationNumber);
      }
    }
  }

  public void readFile(String fileName) throws IOException {
    File file = new File(fileName);
    InputStream inputStream = null;
    try {
      inputStream = new FileInputStream(file);
      // do any operation with the file
    } catch (FileNotFoundException e) { // don't generalize with top level exceptions
      e.printStackTrace(); // don't use stderr use the Logger!
      throw e;
    } finally {
      if (inputStream != null) {
        inputStream.close();
      }
    }
  }

  public void readFileJava7plus(String fileName) throws IOException {
    File file = new File(fileName);
    try (InputStream inputStream = new FileInputStream(file)) { // <-- class should implement
                                                                // interface Closeable
      // do any operation with the file
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      throw e;
    }
  }
}
