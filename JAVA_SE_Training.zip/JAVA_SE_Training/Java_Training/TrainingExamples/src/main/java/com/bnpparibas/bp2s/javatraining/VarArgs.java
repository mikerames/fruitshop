package com.bnpparibas.bp2s.javatraining;

import java.util.Arrays;


public class VarArgs {
  public static void main(String[] args) {
    Object obj = new String("Hello");
    print(obj);
    print(new String("Hello"));
  }

  public static void print(Object... objects) {
    System.out.println("Printing objects: " + Arrays.toString(objects));
  }

  public static void print(String... strings) {
    System.out.println("Printing strings: " + Arrays.toString(strings));
  }
}
