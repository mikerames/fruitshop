package com.bnpparibas.bp2s.javatraining.generics;

import java.util.ArrayList;
import java.util.List;

public class Algorithm {
  public static <T extends Object & Comparable<? super T>> T max(List<? extends T> list, int begin, int end) {
    T maxElem = list.get(begin);
    for (++begin; begin < end; ++begin)
      if (maxElem.compareTo(list.get(begin)) < 0)
        maxElem = list.get(begin);

    return maxElem;
  }

  public static <T extends Comparable<T>> T max2(List<T> list, int begin, int end) {
    T maxElem = list.get(begin);
    for (++begin; begin < end; ++begin) {
      if (maxElem.compareTo(list.get(begin)) < 0) {
        maxElem = list.get(begin);
      }
    }
    return maxElem;
  }

  public static void main(String[] args) {
    List<Integer> intList = new ArrayList<>();
    intList.add(2);
    intList.add(10);
    intList.add(45);
    intList.add(12);
    intList.add(21);
    intList.add(25);

    System.out.println(max(intList, 1, 5));
    System.out.println(max2(intList, 1, 5));
  }
}
