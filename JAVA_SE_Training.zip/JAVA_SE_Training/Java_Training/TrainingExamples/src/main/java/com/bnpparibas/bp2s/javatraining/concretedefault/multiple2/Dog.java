package com.bnpparibas.bp2s.javatraining.concretedefault.multiple2;

public interface Dog extends Animal {
  default String makeSound() {
    return "Au au";
  }
}
