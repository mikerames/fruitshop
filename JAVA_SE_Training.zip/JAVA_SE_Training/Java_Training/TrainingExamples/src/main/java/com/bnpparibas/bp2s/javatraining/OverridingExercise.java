package com.bnpparibas.bp2s.javatraining;

public class OverridingExercise {

  public static void main(String[] args) {
    Bar _bar = new Bar();
    System.out.println(_bar.getMessage());

    Foo _foo = new Foo();
    System.out.println(_foo.getMessage());

    _bar = _foo;
    System.out.println(_bar.getMessage());

    _bar = new Foo();
    System.out.println(_bar.getMessage());
  }
}
