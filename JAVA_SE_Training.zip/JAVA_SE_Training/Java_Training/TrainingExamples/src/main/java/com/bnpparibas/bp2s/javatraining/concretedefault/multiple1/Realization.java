package com.bnpparibas.bp2s.javatraining.concretedefault.multiple1;

public class Realization implements MegaInterface {
}
