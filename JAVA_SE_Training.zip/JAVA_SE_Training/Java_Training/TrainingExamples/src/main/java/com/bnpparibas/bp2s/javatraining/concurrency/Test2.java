package com.bnpparibas.bp2s.javatraining.concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test2 {
  public static void main(String[] args) {
    System.out.println("With normal shutdown:");
    launchExec1();
    System.out.println("With shutdownNow:");
    launchExec2();
  }

  private static void launchExec1() {
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Runnable r = () -> {
      try {
        Thread.sleep(5000);
        System.out.println("launchExec1 end");
      } catch (InterruptedException e) {
        System.out.println("Interrupted");
      }
    };
    executor.execute(r);
    executor.shutdown();
  }

  private static void launchExec2() {
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Runnable r = () -> {
      try {
        Thread.sleep(5000);
        System.out.println("launchExec2 end");
      } catch (InterruptedException e) {
        System.out.println("Interrupted");
      }
    };
    executor.execute(r);
    executor.shutdownNow();
  }
}
