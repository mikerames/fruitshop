package com.bnpparibas.bp2s.javatraining.objectstream;

public class Application {
  public static void main(String[] args) {
    User user = new User("Malaquias", "Topolino");
    System.out.println("User saved success:" + SaveUser.save(user));

    User user2 = ReadUser.read();
    System.out.println("User readed from File:" + user2.toString());

  }
}
