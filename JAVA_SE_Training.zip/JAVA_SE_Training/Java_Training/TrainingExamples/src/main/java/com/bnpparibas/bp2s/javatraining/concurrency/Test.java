package com.bnpparibas.bp2s.javatraining.concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class Test {
  public static void main(String[] args) {
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Runnable r = () -> {
      IntStream.rangeClosed(1, 4).forEach(System.out::println);
    };
    System.out.println("before executing");
    executor.execute(r);
    System.out.println("after executing");
    executor.shutdown();
  }
}
