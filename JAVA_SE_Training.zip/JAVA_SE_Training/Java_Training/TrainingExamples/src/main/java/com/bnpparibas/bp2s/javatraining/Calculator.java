package com.bnpparibas.bp2s.javatraining;


public class Calculator {
  public long add(long... values) {
    long result = 0;
    for (int i = 0; i < values.length; i++) {
      result += values[i];
    }
    return result;
  }

  public long add(long value1, long value2) {
    long[] values = new long[2];
    values[0] = value1;
    values[1] = value2;
    return add(values);
  }

  public static void main(String[] args) {
    Calculator calc = new Calculator();
    System.out.println(calc.add(3, 3, 4));
    System.out.println(calc.add(10, 4));
  }
}
