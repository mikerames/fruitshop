package com.bnpparibas.bp2s.javatraining.lambdas.constructorreferences;


public class Writer extends Person {

  public static enum BookType {
    FICTION
  }

  private BookType bookType;

  public void setBookType(BookType bookType) {
    this.bookType = bookType;
  };

  public BookType getBookType() {
    return bookType;
  };


}
