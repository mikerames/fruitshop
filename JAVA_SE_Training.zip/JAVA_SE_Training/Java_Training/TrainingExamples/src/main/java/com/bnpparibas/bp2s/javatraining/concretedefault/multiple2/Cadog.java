package com.bnpparibas.bp2s.javatraining.concretedefault.multiple2;

public class Cadog implements Dog, Cat {
  @Override
  public String makeSound() {
    // return ((Dog)this).makeSound();
    // or
    return Cat.super.makeSound();
  }

  public static void main(String[] args) {
    Animal animal = new Cadog();
    System.out.println(animal.makeSound());
  }
}
