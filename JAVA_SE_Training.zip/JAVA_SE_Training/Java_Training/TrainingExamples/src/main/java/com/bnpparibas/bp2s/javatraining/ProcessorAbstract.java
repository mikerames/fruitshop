package com.bnpparibas.bp2s.javatraining;

public abstract class ProcessorAbstract extends Processor {

  @Override
  public abstract void calculate(int value1, int value2);
}
