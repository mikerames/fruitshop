package com.bnpparibas.bp2s.javatraining.concretedefault.multiple1;

public class Usage {
  public static void main(String[] args) {
    MegaInterface instance = new Realization();
    System.out.println(instance.doSomething1());
    System.out.println(instance.doSomething2());
  }

}
