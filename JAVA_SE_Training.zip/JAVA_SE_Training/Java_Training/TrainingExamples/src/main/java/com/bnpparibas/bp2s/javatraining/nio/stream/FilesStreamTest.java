package com.bnpparibas.bp2s.javatraining.nio.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.function.BiPredicate;
import java.util.stream.Stream;



public class FilesStreamTest {

  public static void main(String[] args) {
    Path file = Paths.get("C:\\temp\\");
    // System.out.println("Listing -------");
    // list(file);
    // System.out.println("Walking -------");
    // walk(file);
    System.out.println("find -------");
    find(file);

  }

  private static void list(Path file) {
    try (Stream<Path> stream = Files.list(file)) {
      stream.forEach(System.out::println);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void walk(Path file) {
    try (Stream<Path> stream = Files.walk(file, 1)) {
      stream.forEach(System.out::println);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void find(Path file) {
    BiPredicate<Path, BasicFileAttributes> predicate = (path, attrs) -> {
      return attrs.isDirectory();
    };
    int maxDepth = 1;
    try (Stream<Path> stream = Files.find(file, maxDepth, predicate)) {
      stream.forEach(System.out::println);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
