package com.bnpparibas.bp2s.javatraining;

public class IntegerExtension {
  boolean negative = false;
  private Integer value;

  public IntegerExtension(int value) {
    this(String.valueOf(value));
  }

  public IntegerExtension(String value) {
    this.value = new Integer(value);
    if (this.value < 0)
      negative = true;
  }

  public boolean isNegative() {
    return negative;
  }

  public boolean isPositive() {
    return !negative;
  }
}
