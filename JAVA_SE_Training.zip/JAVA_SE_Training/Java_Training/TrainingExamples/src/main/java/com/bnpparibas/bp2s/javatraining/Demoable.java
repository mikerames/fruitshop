package com.bnpparibas.bp2s.javatraining;

public interface Demoable {

}
