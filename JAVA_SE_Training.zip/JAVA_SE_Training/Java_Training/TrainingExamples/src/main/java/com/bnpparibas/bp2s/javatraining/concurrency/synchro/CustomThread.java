package com.bnpparibas.bp2s.javatraining.concurrency.synchro;


public class CustomThread implements Runnable {

  private String threadName;
  private Test test;

  public CustomThread(String threadName, Test test) {
    this.test = test;
    this.threadName = threadName;
  }

  @Override
  public void run() {
    test.output2(threadName);
    test.output(threadName);
  }
}
