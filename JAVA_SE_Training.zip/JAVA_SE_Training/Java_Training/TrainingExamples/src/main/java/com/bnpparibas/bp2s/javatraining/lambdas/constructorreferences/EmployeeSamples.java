package com.bnpparibas.bp2s.javatraining.lambdas.constructorreferences;

public interface EmployeeSamples {
  static Person randomEmployee() {
    return new Person();
  }
}
