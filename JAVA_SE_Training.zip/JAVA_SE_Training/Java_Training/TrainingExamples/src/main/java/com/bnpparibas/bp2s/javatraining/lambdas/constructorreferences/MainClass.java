package com.bnpparibas.bp2s.javatraining.lambdas.constructorreferences;

import java.util.Random;
import java.util.function.Supplier;


public class MainClass {
  private final static Supplier[] peopleGenerators = {Person::new, Writer::new, Artist::new, Consultant::new,
      // example of calling randomEmployee static method
      EmployeeSamples::randomEmployee,
      // Example for writer constructor with data
      () -> {
        Writer w = new Writer();
        w.setFirstName("Ernest");
        w.setLastName("Hemingway");
        w.setBookType(Writer.BookType.FICTION);
        return w;
      }};

  public static Person randomPerson() {
    Random rand = new Random();
    Supplier<Person> generator = peopleGenerators[rand.nextInt(peopleGenerators.length)];
    return generator.get();
  }


  public static void main(String[] args) {

    for (int i = 1; i <= 20; i++) {
      Person person = randomPerson();
      System.out.println("Type:" + person.getClass().getName() + " FN: " + person.getFirstName());
    }
  }
}
