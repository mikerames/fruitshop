package com.bnpparibas.bp2s.javatraining;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileSystemException;



public class Main {
  public static void main(String args[]) throws IOException {
    try {
      String saudacao = new String();
      saudacao = "";
      saudacao = "";

      method1();
      method2();
    } catch (FileNotFoundException | FileSystemException e) {
      throw e;
    }
  }

  public static void method1() throws FileSystemException {
    throw new FileSystemException("Ups File System Exception");
  }

  public static void method2() throws FileNotFoundException {
    throw new FileNotFoundException();
  }

}
