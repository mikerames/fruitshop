package com.bnpparibas.bp2s.javatraining.lambdas.methodreferences;


@FunctionalInterface
public interface StringFunction {
  String applyFunction(String s);
}
