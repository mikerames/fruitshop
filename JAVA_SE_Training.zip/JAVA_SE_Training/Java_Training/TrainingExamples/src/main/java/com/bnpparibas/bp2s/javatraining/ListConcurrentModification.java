package com.bnpparibas.bp2s.javatraining;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class ListConcurrentModification {

  public static void main(String args[]) {
    List<String> stringList = new ArrayList<>();
    /*
     * for (int i = 0; i < 500; i++) { stringList.add(String.valueOf(i)); } int i = 0;
     * stringList.clear();
     */
    int i = 0;
    // stringList = null;
    Iterator<String> stringIterator = stringList.iterator();
    while (stringIterator.hasNext()) {
      String string = stringIterator.next();
      System.out.println(string);
    }

    for (int j = 0; j < stringList.size(); j++) {
      System.out.println(stringList.get(j));
    }

    java.util.Collection<String> list = new ArrayList<>();
    for (String str : stringList) {
      stringList.add(i + "");
      i++;
    }


  }
}
