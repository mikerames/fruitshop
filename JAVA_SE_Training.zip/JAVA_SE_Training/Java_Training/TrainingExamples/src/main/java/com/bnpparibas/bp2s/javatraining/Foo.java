package com.bnpparibas.bp2s.javatraining;

public class Foo extends Bar {

  public Foo() {
    System.out.println("Foo created!");
  }

  @Override
  public String getMessage() {
    return "Foo here!";
  }
}
