package com.bnpparibas.bp2s.javatraining.concretedefault.multiple1;

public interface Interface2 {
  default int doSomething2() {
    return 2;
  }
}
