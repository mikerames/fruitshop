package com.bnpparibas.bp2s.javatraining;

public class SingletonClient {

  public static void main(String[] args) {
    for (int i = 0; i < 50; i++)
      System.out.println(SingletonClass.getInstance().executeAction());
  }
}
