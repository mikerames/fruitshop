package com.bnpparibas.bp2s.javatraining;



public class ClassWithoutStatic {
  private Client client;

  public ClassWithoutStatic() {
    client = new Client(1);
  }

  public void editClientName(String name) {
    client.setName(name);
  }

  public Client getClient() {
    return client;
  }

  public static void main(String[] args) {
    ClassWithoutStatic instance = new ClassWithoutStatic();
    instance.editClientName("John Doe");
    System.out.println(instance.getClient().getName());
  }
}
