package com.bnpparibas.bp2s.javatraining;

public abstract class AbstractClass {

  private int value;

  void setNumber(int value) {
    this.value = value;
  }

  int getNumber() {
    return value;
  }

  public abstract void calculate(int value1, int value2);

}
