package com.bnpparibas.bp2s.javatraining;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;



public class DateDemonstration {

  public static void main(String[] args) {
    final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    // Get an input string and parse it into a date
    String input = "12-12-1994";
    LocalDate date = LocalDate.parse(input, formatter);
    System.out.printf("Parsed Date: %s%n", date);

    // Format a date to a specific output string format
    LocalDate localDate = LocalDate.now();
    System.out.printf("Date Value: %s%n", localDate);
    System.out.printf("Formated Date: %s%n", localDate.format(formatter));

  }

}
