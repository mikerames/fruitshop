package com.bnpparibas.bp2s.javatraining;



public class ArraysTest {
  public static void main(String[] args) {
    int[][] arrayOfInts = { {2, 0, 6, 1}, {7, 1, 5, 1}, {3, 0, 2, 7}};
    int sum = 0;
    for (int y = 0; y < arrayOfInts.length; y++) {
      int line = 0;
      for (int x = 0; x < arrayOfInts[y].length; x++) {
        line += arrayOfInts[y][x];
      }
      System.out.println("Total line [" + y + "]:" + line);
      sum += line;
    }
    System.out.println("Total Value:" + sum);
  }
}
