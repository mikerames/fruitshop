package com.bnpparibas.bp2s.javatraining;


public class ConstructorDemo {
  private String firstName;
  private String lastName;


  public ConstructorDemo(String completeName) {
    System.out.println("ConstructorDemo(String completeName)");
    this.firstName = completeName.split(" ")[0];
    this.lastName = completeName.split(" ")[1];
  }

  public ConstructorDemo(String firstName, String lastName) {
    System.out.println("ConstructorDemo(String firstName, String lastName)");
    this.firstName = firstName;
    this.lastName = lastName;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

}
