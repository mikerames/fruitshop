package com.bnpparibas.bp2s.javatraining.objectstream;

import java.io.Serializable;

public class User implements Serializable {


  /**
   * 
   */
  private static final long serialVersionUID = 3616829953239290766L;
  private String firstName;
  private String lastName;

  public User(String firstName, String lastName) {
    super();
    this.firstName = firstName;
    this.lastName = lastName;
  }



  public String getLastName() {
    return lastName;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  @Override
  public boolean equals(Object obj) {
    return obj == null || (this.firstName.equals(((User) obj).firstName) && this.lastName.equals(((User) obj).lastName));
  }

  @Override
  public String toString() {
    return getFirstName() + " " + getLastName();
  }
}
