package com.bnpparibas.bp2s.javatraining.patterns.builderpattern;


public class EmailMessageProblem {

  private String from;
  private String to;
  private String subject;
  private String content;
  private String mimeType; // optional

  public EmailMessageProblem(String from, String to, String subject, String content) {
    this(from, to, subject, content, null);
  }

  public EmailMessageProblem(String from, String to, String subject, String content, String mimeType) {
    this.from = from;
    this.to = to;
    this.subject = subject;
    this.content = content;
    this.mimeType = mimeType;
  }
}
