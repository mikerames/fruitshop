package com.bnpparibas.bp2s.javatraining;

public class EnhancedForLoopExample {
  public static void main(String[] args) {
    System.out.println(factorize(8));
    System.out.println(factorize(4));

  }

  private static int factorize(int i) {
    if (i <= 1) {
      return i;
    }
    return i * factorize(i - 1);
  }
}
