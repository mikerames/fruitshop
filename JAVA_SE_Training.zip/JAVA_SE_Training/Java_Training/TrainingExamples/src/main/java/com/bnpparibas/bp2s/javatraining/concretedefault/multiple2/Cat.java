package com.bnpparibas.bp2s.javatraining.concretedefault.multiple2;

public interface Cat extends Animal {
  default String makeSound() {
    return "Meow";
  }
}
