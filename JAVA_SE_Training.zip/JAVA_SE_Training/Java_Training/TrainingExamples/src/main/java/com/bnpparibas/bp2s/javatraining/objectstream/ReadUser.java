package com.bnpparibas.bp2s.javatraining.objectstream;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadUser {
  public static User read() {
    try (FileInputStream fileInputStream = new FileInputStream("./user.txt"); ObjectInputStream input = new ObjectInputStream(fileInputStream)) {
      return (User) input.readObject();
    } catch (IOException | ClassNotFoundException e) {
      e.printStackTrace();
      return null;
    }
  }
}
