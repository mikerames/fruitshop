package com.bnpparibas.bp2s.javatraining;

import java.util.Scanner;



public class InOutScanner {
  public static void main(String args[]) {
    try (Scanner scanner = new Scanner(System.in)) {
      String input;
      do {
        System.out.print("Enter something : ");
        input = scanner.nextLine();
        System.out.println("Echoing your input : " + input);
        System.out.println("-----------\n");
      } while (!"q".equals(input));
      System.out.println("Bye bye!");
    }
  }

}
