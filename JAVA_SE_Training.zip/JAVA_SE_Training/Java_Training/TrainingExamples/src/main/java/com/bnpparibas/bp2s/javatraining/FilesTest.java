package com.bnpparibas.bp2s.javatraining;

import java.nio.file.Files;
import java.nio.file.Paths;



public class FilesTest {
  public static void main(String[] args) {
    if (Files.exists(Paths.get("C:\\temp\\temp.txt"))) {
      System.out.println("File Exists.");
    } else {
      if (!Files.notExists(Paths.get("C:\\temp\\temp.txt"))) {
        System.out.println("It's not possible to assess if File exists.");
      } else {
        System.out.println("File doesn't exists.");
      }
    }
  }
}
