package com.bnpparibas.bp2s.javatraining;

import java.io.Console;


// ECLIPSE BUG!!! Isn't able to attach Console. Meanwhile executing with:
// c:\tools\jdk1.8.0_05\bin\java.exe -cp miscellanious.jar
// com.bnpparibas.bp2s.javatraining.InOutConsole
// works as expected.
public class InOutConsole {
  public static void main(String args[]) {
    Console consoleInput = System.console();
    if (consoleInput == null) {
      System.err.println("No console.");
      System.exit(1);
    }
    String input;
    do {
      System.out.print("Enter something : ");
      input = consoleInput.readLine();
      System.out.println("Echoing your input : " + input);
      System.out.println("-----------\n");
    } while (!"q".equals(input));
    System.out.println("bye bye!");

    /*
     * String input; do { System.out.print("Enter something : "); input =
     * System.console().readLine(); System.out.println("Echoing your input : " + input);
     * System.out.println("-----------\n"); } while (!"q".equals(input));
     * System.out.println("Exit!"); System.exit(0);
     */
  }

}
