package com.bnpparibas.bp2s.javatraining.lambdas.methodreferences;


public class MainClass {
  public static void main(String[] args) {
    String s = "Test";
    // SomeClass::staticMethod
    System.out.println(Utils.transform(s, Utils::makeExciting));
    // someObject::instanceMethod
    String prefix = "Blah";
    System.out.println(Utils.transform(s, prefix::concat));
    // SomeClass::instanceMethod
    System.out.println(Utils.transform(s, String::toUpperCase));
  }
}
