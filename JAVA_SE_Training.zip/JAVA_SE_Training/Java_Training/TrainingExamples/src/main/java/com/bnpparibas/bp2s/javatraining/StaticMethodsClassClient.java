package com.bnpparibas.bp2s.javatraining;



public class StaticMethodsClassClient {

  public static void main(String[] args) {
    StaticMethodsClass.method1();
  }
}
