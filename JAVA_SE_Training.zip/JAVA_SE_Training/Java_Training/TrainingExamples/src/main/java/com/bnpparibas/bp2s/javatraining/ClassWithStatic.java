package com.bnpparibas.bp2s.javatraining;



public class ClassWithStatic {
  private static Client client = new Client(1);

  public static void editClientName(String name) {
    client.setName(name);
  }

  public static void main(String[] args) {
    editClientName("John Doe");
    System.out.println(client.getName());
  }
}
