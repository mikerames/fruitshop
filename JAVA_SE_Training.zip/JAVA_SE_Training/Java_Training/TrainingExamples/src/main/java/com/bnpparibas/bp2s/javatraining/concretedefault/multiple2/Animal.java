package com.bnpparibas.bp2s.javatraining.concretedefault.multiple2;

public interface Animal {
  public String makeSound();
}
