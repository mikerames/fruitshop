package com.bnpparibas.bp2s.javatraining;

public class Bar {
  public Bar() {
    System.out.println("Bar created!");
  }

  public String getMessage() {
    return "Bar here!";
  }
}
