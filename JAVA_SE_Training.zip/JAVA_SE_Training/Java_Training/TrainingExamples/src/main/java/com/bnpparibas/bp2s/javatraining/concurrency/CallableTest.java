package com.bnpparibas.bp2s.javatraining.concurrency;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableTest {
  public static void main(String[] args) {
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Callable<String> task = () -> {
      try {
        Thread.sleep(5_000);
      } catch (InterruptedException e) {
        System.out.println("Interrupted");
      }
      return "Hello world";
    };



    System.out.println("Submitting Callable");
    Future<String> value = executor.submit(task);
    System.out.println("I've submitted the task, now I'm waiting...");
    try {
      String result = value.get();
      System.out.println("And the result is...: " + result);
    } catch (InterruptedException | ExecutionException e) {
      System.out.println("Future canceled or execution interrupted...");
    }
    executor.shutdown();
    System.out.println("Finished!");

  }

}
