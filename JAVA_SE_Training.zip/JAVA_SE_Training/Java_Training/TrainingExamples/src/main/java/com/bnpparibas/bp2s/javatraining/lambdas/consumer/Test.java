package com.bnpparibas.bp2s.javatraining.lambdas.consumer;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Test {

  class Employee {
    public String firstName;
    public String lastName;
    public double salary;

    Employee(String firstName, String lastName, double salary) {
      this.firstName = firstName;
      this.lastName = lastName;
      this.salary = salary;
    }

    @Override
    public String toString() {
      return firstName + " " + lastName + " : " + salary;
    }
  }

  public static void main(String[] args) {
    Test instance = new Test();
    List<Employee> employees = Arrays.asList(instance.new Employee("John", "Doe", 300), instance.new Employee("Mark", "Black", 450));
    acceptAllEmployee(employees, e -> {
      e.salary *= 1.5;
    });
    acceptAllEmployee(employees, System.out::println);
  }

  public static void acceptAllEmployee(List<Employee> employee, Consumer<Employee> printer) {
    for (Employee e : employee) {
      printer.accept(e);
    }
  }
}
