package com.bnpparibas.bp2s.javatraining.nio.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;



public class FilesStreamReadTest {

  public static void main(String[] args) {
    Path file = Paths.get("C:\\temp\\temp.txt");
    if (!Files.exists(file)) {
      return;
    }
    // read file into stream, try-with-resources
    try (Stream<String> stream = Files.lines(file)) {
      stream.forEach(System.out::println);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
