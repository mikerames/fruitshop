package com.bnpparibas.bp2s.javatraining;

import java.util.Date;


public final class ImmutableMultiplier {
  private final int multiplicator;
  private final int multiplicand;
  private final Date operationDate;

  public ImmutableMultiplier(int multiplicator, int multiplicand) {
    this.multiplicator = multiplicator;
    this.multiplicand = multiplicand;
    operationDate = new Date();
  }

  public int getMultiplicator() {
    return multiplicator;
  }

  public int getMultiplicand() {
    return multiplicand;
  }

  public Date getOperationDate() {
    return new Date(operationDate.getTime());
  }

  public int getResult() {
    return getMultiplicand() * getMultiplicator();
  }
}
