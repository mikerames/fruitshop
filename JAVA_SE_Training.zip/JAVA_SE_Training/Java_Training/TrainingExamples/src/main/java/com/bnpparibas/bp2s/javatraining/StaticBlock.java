package com.bnpparibas.bp2s.javatraining;


public class StaticBlock {
  private static String mystr;
  static {
    mystr = "Static keyword in Java";
    System.out.println("Statically Initialized");
  }

  public static String getString() {
    return mystr;
  }
}
