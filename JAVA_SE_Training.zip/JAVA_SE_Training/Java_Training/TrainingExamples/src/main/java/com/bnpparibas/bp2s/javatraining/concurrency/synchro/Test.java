package com.bnpparibas.bp2s.javatraining.concurrency.synchro;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test {
  private int count = 0;
  private int count2 = 0;

  public static void main(String[] args) {
    ExecutorService executor = Executors.newFixedThreadPool(10);
    Runnable[] r1 = new Runnable[10];
    Test test = new Test();
    for (int i = 0; i < 10; i++) {
      r1[i] = new CustomThread(String.valueOf(i), test);
    }

    for (int i = 0; i < 10; i++) {
      executor.execute(r1[i]);
    }

    executor.shutdown();
  }

  public synchronized void output(String threadName) {
    count++;
    System.out.println("output1 Thread " + threadName + " = " + count);
  }

  public void output2(String threadName) {
    count2++;
    System.out.println("output2 Thread " + threadName + " = " + count2);
  }
}
