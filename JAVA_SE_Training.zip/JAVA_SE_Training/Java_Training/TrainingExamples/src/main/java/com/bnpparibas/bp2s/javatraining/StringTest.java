package com.bnpparibas.bp2s.javatraining;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class StringTest {
  public static void main(String[] args) {
    /*
     * String message = new String(); message += "Hello" + " "; message += "World";
     * System.out.println(message);
     */
    /*
     * String message1 = "Hello"; String message2 = new String(); String message3 = new
     * String("Hello");
     * 
     * char[] arr = {'H', 'e', 'l', 'l', 'o'}; String message4 = new String(arr);
     * 
     * String message5 = new String(arr, 1, 3); // ell
     * 
     * byte[] binaryMessage = new String("Hello").getBytes(); String message6 = new
     * String(binaryMessage);
     * 
     * StringBuilder stringBuilder = new StringBuilder("Hello"); String message7 = new
     * String(stringBuilder);
     * 
     * StringBuffer stringBuffer = new StringBuffer("Hello"); String message8 = new
     * String(stringBuffer);
     */
    /*
     * String message1 = new String("Hello");
     * 
     * System.out.println(message1.substring(3)); System.out.println(message1.substring(1, 3));
     * System.out.println(message1.concat(" World")); System.out.println(message1.replace("l",
     * "L")); System.out.println(message1.replace("ll", ""));
     * System.out.println(message1.replaceAll("[H,l,]", "Z")); System.out.println(message1.trim());
     * System.out.println(message1.toLowerCase()); System.out.println(message1.toUpperCase());
     * 
     * message1.replace("l", "L"); System.out.println(message1);
     */
    /*
     * Integer s1 = new Integer(1); if (s1 == s2) { System.out.println("They are equal!"); } else {
     * System.out.println("Oh no� They are different�"); }
     * 
     * int v1 = 1; Integer s2 = new Integer(1);
     * 
     * if (s1 == v1) { System.out.println("They are equal!"); } else {
     * System.out.println("Oh no� They are different�"); }
     * 
     * int v2 = new Integer(1); if (s1 == v2) { System.out.println("They are equal!"); } else {
     * System.out.println("Oh no� They are different�"); }
     * 
     * Number num;
     * 
     * BigDecimal a; AtomicInteger h;
     * 
     * Integer b; Double d; Short s; BigInteger bi; Byte bte; Long l; Float f; AtomicLong al;
     * AtomicInteger ai;
     */

    List<String> list = new ArrayList<String>();
    list.add("John");
    list.add("Mark");
    list.add("James");
    list.add("Bill");

    for (String name : list) {
      System.out.println(name);
    }

    for (Iterator<String> iterator = list.iterator(); iterator.hasNext();) {
      System.out.println((String) iterator.next());
    }

    Iterator<String> iterator = list.listIterator();
    while (iterator.hasNext()) {
      System.out.println((String) iterator.next());
    }

  }

  private static int factorize(int i) {
    if (i <= 1) {
      return i;
    }
    return i * factorize(i - 1);
  }
}
