package com.bnpparibas.bp2s.javatraining.list;

import java.util.ArrayList;
import java.util.List;

public class ReadedList<T> extends ArrayList<T> implements MarkedList<T> {
  private List<Boolean> readedElementData = new ArrayList<>();

  @Override
  public boolean add(T e) {
    return readedElementData.add(false) && super.add(e);
  }

  @Override
  public T get(int index) {
    readedElementData.set(index, true);
    return super.get(index);
  }

  @Override
  public boolean isReaded(int index) {
    return readedElementData.get(index);
  };


}
