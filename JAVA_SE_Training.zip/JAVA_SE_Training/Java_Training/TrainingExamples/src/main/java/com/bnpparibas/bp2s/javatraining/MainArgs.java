package com.bnpparibas.bp2s.javatraining;




public class MainArgs {
  public static void main(String args[]) {
    System.out.println("Your arguments are:");
    for (String arg : args) {
      System.out.println(arg);
    }
  }

}
