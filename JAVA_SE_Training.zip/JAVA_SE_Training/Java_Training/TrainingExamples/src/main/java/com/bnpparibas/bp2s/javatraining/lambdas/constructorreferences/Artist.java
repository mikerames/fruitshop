package com.bnpparibas.bp2s.javatraining.lambdas.constructorreferences;

public class Artist extends Person {

}
