package com.bnpparibas.bp2s.javatraining.concretedefault.multiple1;

public interface Interface1 {
  default int doSomething1() {
    return 1;
  }
}
