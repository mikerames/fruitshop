package com.bnpparibas.bp2s.javatraining;

public class Processor extends AbstractClass {
  @Override
  public void calculate(int value1, int value2) {
    setNumber(value1 * value2);
  }

  public static void main(String args[]) {
    Processor processor = new Processor();
    processor.calculate(10, 5);
    System.out.println(processor.getNumber());
  }
}
