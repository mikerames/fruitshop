package com.bnpparibas.bp2s.javatraining;


public class TopLevel {

  class InnerClass {
    public void printMe() {
      System.out.println("InnerClass");
    }
  }

  public static void main(String args[]) {
    InnerClass instance = new TopLevel().new InnerClass();
    instance.printMe();
  }
}
