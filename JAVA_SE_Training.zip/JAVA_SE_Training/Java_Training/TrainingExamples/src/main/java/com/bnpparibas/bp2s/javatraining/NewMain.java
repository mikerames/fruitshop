package com.bnpparibas.bp2s.javatraining;



public class NewMain {
  public static enum CLUB {
    SCP, FCP, SLB, VSC, VFC
  };

  public static void main(String args[]) {
    String[] stringArrays = new String[] {"a0", "b", "c", "d"};



    for (String position : stringArrays) {
      System.out.println(position);

    }

    System.out.println("end");
  }
}
