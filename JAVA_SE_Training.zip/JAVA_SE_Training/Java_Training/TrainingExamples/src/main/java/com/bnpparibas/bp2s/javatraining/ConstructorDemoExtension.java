package com.bnpparibas.bp2s.javatraining;


public class ConstructorDemoExtension extends ConstructorDemo {
  public ConstructorDemoExtension() {
    super("Alice", "Batatas");
    System.out.println("ConstructorDemoExtension()");
  }

  public static void main(String[] args) {
    ConstructorDemoExtension cd = new ConstructorDemoExtension();
    System.out.println(cd.getFirstName());
  }
}
