package com.bnpparibas.bp2s.javatraining;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;



public class ParsingMainArgs {

  public static void main(String[] args) {
    if (!EntryValidator.isArgsValid(args)) {
      System.out.println("Invalid Arguments!");
      System.exit(-1);
    }
    for (String arg : args) {
      System.out.println(arg);
    }
  }

  private static class EntryValidator {
    public static boolean isArgsValid(String[] args) {
      if (args == null || args.length < 4) {
        return false;
      }

      Float.parseFloat(args[3]);
      final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
      LocalDate.parse(args[2], formatter);

      return true;
    }
  }

}
