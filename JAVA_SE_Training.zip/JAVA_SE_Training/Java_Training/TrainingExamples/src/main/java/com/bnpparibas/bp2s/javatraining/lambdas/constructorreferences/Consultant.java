package com.bnpparibas.bp2s.javatraining.lambdas.constructorreferences;

public class Consultant extends Person {

}
