package com.bnpparibas.bp2s.javatraining;

public class SingletonClass {
  private int status = 0;

  private SingletonClass() {}

  private static class SingletonHelper {
    private static final SingletonClass INSTANCE = new SingletonClass();
  }

  public static SingletonClass getInstance() {
    return SingletonHelper.INSTANCE;
  }

  public int executeAction() {

    return ++status;
  }
}
