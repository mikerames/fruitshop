package com.bnpparibas.bp2s.javatraining;



public class StaticMethodsClass {
  // Note that it's a good practice to have the constructor private when all the methods are static.
  private StaticMethodsClass() {}

  public static void method1() {}

  public static void method2() {}

  public static void method3() {}

  public static void method4() {}

  public static void method5() {}

  public static void method6() {}

  public static void method7() {}

  public static void method8() {}
}
