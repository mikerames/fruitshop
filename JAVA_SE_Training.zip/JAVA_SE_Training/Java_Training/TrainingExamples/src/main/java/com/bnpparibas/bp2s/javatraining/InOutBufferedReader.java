package com.bnpparibas.bp2s.javatraining;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class InOutBufferedReader {
  public static void main(String args[]) {
    try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
      while (true) {
        System.out.print("Enter something (q to quit): ");
        String input = br.readLine();
        if ("q".equals(input)) {
          System.out.println("Bye bye!");
          System.exit(0);
        }
        System.out.println("echoing your input : " + input);
        System.out.println("-----------\n");
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
