package com.bnpparibas.bp2s.javatraining.objectstream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SaveUser {
  public static boolean save(User user) {
    try (FileOutputStream fileOutputStream = new FileOutputStream("./user.txt"); ObjectOutputStream output = new ObjectOutputStream(fileOutputStream)) {
      output.writeObject(user);
      return true;
    } catch (IOException e) {
      e.printStackTrace();
      return false;
    }
  }
}
