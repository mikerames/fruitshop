package com.bnpparibas.bp2s.javatraining;

import java.util.Date;

public class Client {
  String name;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Date getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(Date birthDate) {
    this.birthDate = birthDate;
  }

  Date birthDate;
  int id;

  public Client(int id) {
    this.id = id;
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof Client)) {
      return false;
    }
    if (this.id == ((Client) o).id) {
      return true;
    }
    return false;
  }
}
