package com.bnpparibas.bp2s.javatraining.list;

import java.util.List;

public interface MarkedList<T> extends List<T> {
  boolean isReaded(int index);
}
