package com.bnpparibas.bp2s.javatraining.concretedefault.multiple1;

public interface MegaInterface extends Interface1, Interface2 {
}
