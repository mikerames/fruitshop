package com.bnpparibas.bp2s.javatraining.patterns.builderpattern;


public class Main {

  public static void main(String args[]) {
    EmailMessage email = EmailMessage.builder()
        .from("trainer@example.com")
        .to("trainee@crisp.se")
        .subject("hello dear trainee")
        .content("email content")
        .build();
  }
}
