package com.bnpparibas.bp2s.javatraining;

import static org.junit.Assert.assertTrue;


public class Main {

  private Main() {}

  public static void main(String args[]) {
    executeWithoutAssertion(new Garage());
  }

  private static void executeWithoutAssertion(Garage garage) {
    garage.addNewCarToStock(new Car("Renault"));
    garage.addNewCarToStock(new Car("Opel"));
    garage.addNewCarToStock(new Car("Mercedes"));
    garage.addNewCarToStock(new Car("Opel"));
    garage.listStockCar();

    System.out.println("----------- Updating information with method 1 ------------");
    Car carToBeUpdated = garage.getCarStockList().get(0);
    assertTrue(garage.editCarName(carToBeUpdated, "Citroen"));
    garage.listStockCar();
    System.out.println("----------- Updating information with method 2 ------------");
    assertTrue(garage.editCarName("Citroen", "Peugeot"));
    garage.listStockCar();
    System.out.println("----------- Finish updates ------------");

    garage.sellCar(garage.getCarStockList().get(0), 3223.44f);
    garage.sellCar(garage.getCarStockList().get(0), 5293.66f);
    garage.sellCar(garage.getCarStockList().get(0), 13.16f);
    garage.listStockCar();
    garage.listSoldCars();
  }

}
