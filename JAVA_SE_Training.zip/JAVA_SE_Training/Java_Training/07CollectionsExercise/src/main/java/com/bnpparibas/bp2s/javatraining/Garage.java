package com.bnpparibas.bp2s.javatraining;

import java.util.ArrayList;
import java.util.List;


class Garage {

  private List<Car> carStock = new ArrayList<>();
  private List<SoldCar> soldCars = new ArrayList<>();

  public boolean addNewCarToStock(Car newCar) {
    if (!carStock.contains(newCar)) {
      carStock.add(newCar);
      return true;
    }
    return false;
  }

  public boolean sellCar(Car soldCar, float price) {
    if (carStock.contains(soldCar)) {
      carStock.remove(soldCar);
      soldCars.add(new SoldCar(soldCar, price));
      return true;
    }
    return false;
  }

  public void listStockCar() {
    for (Car car : carStock) {
      System.out.println("Car with brand:" + car.getBrand());
    }
  }

  public void listSoldCars() {
    float totalSold = 0;
    for (SoldCar car : soldCars) {
      totalSold += car.getPrice();
      System.out.println("-------------------");
      System.out.println("Brand:" + car.getCar().getBrand() + "\nPrice:" + car.getPrice());
    }
    System.out.println("---------------------------------------------");
    System.out.println("Total value sold:" + totalSold + "€");
  }

  public List<Car> getCarStockList() {
    return carStock;
  }
}
