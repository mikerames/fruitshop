package com.bnpparibas.bp2s.javatraining;

public class Car {
  private String brand;

  public Car(String brand) {
    this.brand = brand;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  @Override
  public boolean equals(Object other) {
    if (!(other instanceof Car)) {
      return false;
    }
    if (this.brand.equalsIgnoreCase(((Car) other).getBrand())) {
      return true;
    }
    return false;
  }

}
