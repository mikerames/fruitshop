package com.bnpparibas.bp2s.javatraining;

public class SoldCar {
  private Car car;
  private float price;

  public SoldCar(Car car, float price) {
    this.setCar(car);
    this.setPrice(price);
  }

  public Car getCar() {
    return car;
  }

  public void setCar(Car car) {
    this.car = car;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

}
