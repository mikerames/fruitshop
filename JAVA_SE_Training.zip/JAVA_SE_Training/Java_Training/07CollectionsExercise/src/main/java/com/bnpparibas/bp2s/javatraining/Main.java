package com.bnpparibas.bp2s.javatraining;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


public class Main {

  public static void main(String args[]) {
    executeWithoutAssertion(new Garage());


    // Lets introduce assertions... And do a quick jump to unit test :)
    // executeWithAssertion(new Garage());

    // and with an assertion error?
    // executeWithAssertionError(new Garage());
    // System.out.println("the end...");

  }

  private static void executeWithoutAssertion(Garage garage) {
    garage.addNewCarToStock(new Car("Renault"));
    garage.addNewCarToStock(new Car("Opel"));
    garage.addNewCarToStock(new Car("Mercedes"));
    garage.addNewCarToStock(new Car("Opel"));
    garage.listStockCar();
    garage.sellCar(garage.getCarStockList().get(0), 3223.44f);
    garage.sellCar(garage.getCarStockList().get(0), 5293.66f);
    garage.sellCar(garage.getCarStockList().get(0), 13.16f);
    garage.listStockCar();
    garage.listSoldCars();
  }

  private static void executeWithAssertion(Garage garage) {
    assertTrue(garage.addNewCarToStock(new Car("Renault")));
    assertTrue(garage.addNewCarToStock(new Car("Opel")));
    assertTrue(garage.addNewCarToStock(new Car("Mercedes")));
    assertFalse(garage.addNewCarToStock(new Car("Opel")));
    garage.listStockCar();
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 3223.44f));
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 5293.66f));
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 13.16f));
    garage.listStockCar();
    garage.listSoldCars();
  }

  private static void executeWithAssertionError(Garage garage) {
    assertTrue(garage.addNewCarToStock(new Car("Renault")));
    assertTrue(garage.addNewCarToStock(new Car("Opel")));
    assertTrue(garage.addNewCarToStock(new Car("Mercedes")));
    assertTrue(garage.addNewCarToStock(new Car("Opel")));
    garage.listStockCar();
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 3223.44f));
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 5293.66f));
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 13.16f));
    garage.listStockCar();
    garage.listSoldCars();
  }
}
