package com.bnpparibas.bp2s.javatraining;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;


public class GarageTest {

  @Test
  public void testCompleteFlow() {
    Garage garage = new Garage();
    assertTrue(garage.addNewCarToStock(new Car("Renault")));
    assertTrue(garage.addNewCarToStock(new Car("Opel")));
    assertTrue(garage.addNewCarToStock(new Car("Mercedes")));
    assertFalse(garage.addNewCarToStock(new Car("Opel")));
    garage.listStockCar();
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 3223.44f));
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 5293.66f));
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 13.16f));
    garage.listStockCar();
    garage.listSoldCars();
  }

  @Test
  public void testAddCars() {
    Garage garage = new Garage();
    assertTrue(garage.addNewCarToStock(new Car("Renault")));
    assertTrue(garage.addNewCarToStock(new Car("Opel")));
    assertTrue(garage.addNewCarToStock(new Car("Mercedes")));
    assertFalse(garage.addNewCarToStock(new Car("Opel")));
    assertFalse(garage.addNewCarToStock(new Car("opel")));
    assertEquals(3, garage.getCarStockList().size());
  }

  @Test
  public void testSellCars() {
    Garage garage = new Garage();
    assertTrue(garage.addNewCarToStock(new Car("Renault")));
    assertTrue(garage.addNewCarToStock(new Car("Opel")));
    assertTrue(garage.addNewCarToStock(new Car("Mercedes")));

    int carsQty = garage.getCarStockList().size();
    assertTrue(garage.sellCar(garage.getCarStockList().get(0), 100.00f));
    assertEquals(2, carsQty - 1);
  }
}
