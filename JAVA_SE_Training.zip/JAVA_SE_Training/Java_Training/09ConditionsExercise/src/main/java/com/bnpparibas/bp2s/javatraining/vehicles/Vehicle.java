package com.bnpparibas.bp2s.javatraining.vehicles;

public interface Vehicle {
  public String getBrand();

  public void setBrand(String brand);

  public String getType();

  public void setType(String type);

}
