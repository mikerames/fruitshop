package com.bnpparibas.bp2s.javatraining.vehicles;


public class SoldVehicle {
  private Vehicle vehicle;
  private float price;

  public SoldVehicle(Vehicle vehicle, float price) {
    this.setVehicle(vehicle);
    this.setPrice(price);
  }

  public Vehicle getVehicle() {
    return vehicle;
  }

  public void setVehicle(Vehicle vehicle) {
    this.vehicle = vehicle;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

}
