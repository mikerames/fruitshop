package com.bnpparibas.bp2s.javatraining;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.bnpparibas.bp2s.javatraining.business.Garage;
import com.bnpparibas.bp2s.javatraining.vehicles.Vehicle;
import com.bnpparibas.bp2s.javatraining.vehicles.VehicleFactory;

public class Main {

  public static void main(String[] args) {
    Garage garage = new Garage();
    assertTrue(garage.addNewVehicleToStock(VehicleFactory.getInstance("Car", "Renault")));
    assertTrue(garage.addNewVehicleToStock(VehicleFactory.getInstance("Motorcycle", "Yamaha")));
    assertTrue(garage.addNewVehicleToStock(VehicleFactory.getInstance("Car", "Mercedes")));
    assertTrue(garage.addNewVehicleToStock(VehicleFactory.getInstance("Truck", "Scania")));
    assertFalse(garage.addNewVehicleToStock(VehicleFactory.getInstance("Car", "Renault")));
    garage.listVehicleStock();

    System.out.println("----------- Updating information with method 1 ------------");
    Vehicle vehicleToBeUpdated = garage.getCarStockList().get(0);
    assertTrue(garage.editVehicleBrand(vehicleToBeUpdated, "Citroen"));
    garage.listVehicleStock();
    System.out.println("----------- Updating information with method 2 ------------");
    assertTrue(garage.editVehicleBrand("Citroen", "Peugeot"));
    garage.listVehicleStock();
    System.out.println("----------- Finish updates ------------");

    assertTrue(garage.sellVehicle(garage.getCarStockList().get(0), 3223.44f));
    assertTrue(garage.sellVehicle(garage.getCarStockList().get(0), 5293.66f));
    assertTrue(garage.sellVehicle(garage.getCarStockList().get(0), 13.16f));

    garage.listVehicleStock();
    garage.listSoldCars();
  }
}
