package com.bnpparibas.bp2s.javatraining;

import java.util.stream.IntStream;


public class PrimeCalculator {

  public static void main(String args[]) {
    System.out.println("Solution 1");
    for (int i = 1; i <= 60; i++) {
      if (isPrimeSolution1(i)) {
        System.out.printf(String.valueOf(i) + ", ");
      }
    }
    System.out.println("...\n\nSolution 2");
    for (int i = 1; i <= 60; i++) {
      if (isPrimeSolution2(i)) {
        System.out.printf(String.valueOf(i) + ", ");
      }
    }
    System.out.printf("...");
  }

  public static boolean isPrimeSolution1(int number) {
    if (number <= 1) {
      return false;
    }
    int countDivisor = 0;
    for (int i = number; i > 1; i--) {
      if (number % i == 0) {
        countDivisor++;
      }
    }
    if (countDivisor > 1) {
      return false;
    }
    return true;
  }

  public static boolean isPrimeSolution2(int number) {
    return number > 1 && IntStream.range(2, number - 1).noneMatch(divisor -> number % divisor == 0);
  }

}
