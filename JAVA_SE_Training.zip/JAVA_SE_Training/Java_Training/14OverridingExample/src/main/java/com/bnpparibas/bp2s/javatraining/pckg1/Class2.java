package com.bnpparibas.bp2s.javatraining.pckg1;

class Class2 {
  public Class2() {
    System.out.println("Class2 - Public modifier Constructor");
  }

  protected Class2(int value) {
    System.out.println("Class2 - Protected modifier Constructor with int param");
  }

  Class2(int value1, int value2) {
    System.out.println("Class2 - Default modifier Constructor with 2 int params");
  }

  private void method1() {

  }

  protected void method2() {
    method1();
  }

  void method3() {}

  public void method4() {}
}
