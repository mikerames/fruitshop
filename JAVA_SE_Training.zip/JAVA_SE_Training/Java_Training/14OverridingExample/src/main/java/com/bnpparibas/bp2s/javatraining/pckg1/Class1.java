package com.bnpparibas.bp2s.javatraining.pckg1;

public class Class1 {

  public Class1() {
    System.out.println("Class1 - Public modifier Constructor");
  }

  protected Class1(int value) {
    System.out.println("Class1 - Protected modifier Constructor with int param");
  }

  Class1(int value1, int value2) {
    System.out.println("Class1 - Default modifier Constructor with 2 int params");
  }

  private void method1() {

  }

  protected void method2() {
    method1();
  }

  void method3() {}

  public void method4() {}

  public static void main(String[] args) {
    Class1 class11 = new Class1();
    Class1 class12 = new Class1(1);
    Class1 class13 = new Class1(1, 3);
    class11.method1();
    class11.method2();
    class11.method3();
    class11.method4();
    Class2 class21 = new Class2();
    Class2 class22 = new Class2(1);
    Class2 class23 = new Class2(1, 3);
    // class21.method1();
    class21.method2();
    class21.method3();
    class21.method4();

  }
}
