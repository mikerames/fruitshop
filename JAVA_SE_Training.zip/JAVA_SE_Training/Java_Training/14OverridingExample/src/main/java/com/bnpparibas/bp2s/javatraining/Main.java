package com.bnpparibas.bp2s.javatraining;

import com.bnpparibas.bp2s.javatraining.pckg1.Class1;


public class Main {
  public static void main(String[] args) {

    Class1 class11 = new Class1();
    // Class1 class12 = new Class1(1);
    // Class1 class13 = new Class1(1, 3);
    // class11.method1();
    // class11.method2();
    // class11.method3();
    class11.method4();


  }
}
