package com.bnpparibas.bp2s.javatraining;

public class NameParser {

  public static void main(String args[]) {
    final String NAME = "Carlos Miguel Páscoa Grosso Correia";

    System.out.println("Give Me Any Name: " + getAnyName(NAME));
    System.out.println("Give First and Last Name: " + getFirstAndLastName(NAME));
  }

  public static String getAnyName(String name) {
    String[] names = name.split(" ");
    return names[(int) (Math.random() * names.length)];
  }

  public static String getFirstAndLastName(String name) {
    String[] names = name.split(" ");
    return names[0] + " " + names[names.length - 1];
  }

}
