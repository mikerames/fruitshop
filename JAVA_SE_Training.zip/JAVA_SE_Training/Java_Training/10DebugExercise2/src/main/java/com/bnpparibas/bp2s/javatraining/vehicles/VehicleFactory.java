package com.bnpparibas.bp2s.javatraining.vehicles;

import java.security.InvalidParameterException;


public class VehicleFactory {

  public static Vehicle getInstance(String name, String brandName) {
    switch (name) {
      case "Car":
        return new Car(name, brandName);
      case "Truck":
        return new Truck(name, brandName);
      case "Motorcycle":
        return new Motorcycle(name, brandName);
      default:
        throw new InvalidParameterException("Invalid name!");
    }
  }
}
