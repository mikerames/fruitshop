package com.bnpparibas.bp2s.javatraining.vehicles;



public class Car implements Vehicle {
  private String brand;
  private String type;

  protected Car(String type, String brand) {
    this.type = type;
    this.brand = brand; // ISSUE 1!
  }

  @Override
  public String getBrand() {
    return brand;
  }

  @Override
  public void setBrand(String brand) {
    this.brand = brand;
  }

  @Override
  public String getType() {
    return type;
  }

  @Override
  public void setType(String type) {
    this.type = type;
  }

  @Override
  public boolean equals(Object other) {
    // ISSUE 2
    if (!(other instanceof Car)) {
      return false;
    }
    if (this.brand.equalsIgnoreCase(((Car) other).getBrand()) && this.type.equalsIgnoreCase(((Car) other).getType())) {
      return true;
    }
    return false;
  }
}
