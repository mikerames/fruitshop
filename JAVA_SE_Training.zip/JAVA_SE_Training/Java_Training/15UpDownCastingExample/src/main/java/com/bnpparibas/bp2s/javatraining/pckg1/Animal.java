package com.bnpparibas.bp2s.javatraining.pckg1;

public class Animal {
  public void live() {}
}
