package com.bnpparibas.bp2s.javatraining;

import com.bnpparibas.bp2s.javatraining.pckg1.Animal;
import com.bnpparibas.bp2s.javatraining.pckg1.Dog;



public class Main {
  public static void main(String[] args) {
    // Downcasting
    Animal animal = new Dog();
    Dog downCastedDog = (Dog) animal;
    // Upcasting
    Dog dog = new Dog();
    ((Animal) dog).live();
  }
}
