package com.bnpparibas.bp2s.javatraining.business;

import java.util.ArrayList;
import java.util.List;

import com.bnpparibas.bp2s.javatraining.vehicles.SoldItem;
import com.bnpparibas.bp2s.javatraining.vehicles.Vehicle;


public class Garage {


  private List<Vehicle> vehicleStock = new ArrayList<>();
  private List<SoldItem> soldVehicles = new ArrayList<>();

  public boolean addNewVehicleToStock(Vehicle newVehicle) {
    if (!vehicleStock.contains(newVehicle)) {
      vehicleStock.add(newVehicle);
      return true;
    }
    return false;
  }

  public boolean editVehicleBrand(String previousBrand, String newBrandName) {
    for (Vehicle car : getCarStockList()) {
      if (car.getBrand().equals(previousBrand)) {
        car.setBrand(newBrandName);
        return true;
      }
    }
    return false;
  }

  public boolean editVehicleBrand(Vehicle targetVehicle, String newBrandName) {
    if (targetVehicle != null) {
      targetVehicle.setBrand(newBrandName);
      return true;
    }
    return false;
  }

  public boolean sellVehicle(Vehicle soldVehicle, float price) {
    if (vehicleStock.contains(soldVehicle)) {
      vehicleStock.remove(soldVehicle);
      soldVehicles.add(new SoldItem<Vehicle>(soldVehicle, price));
      return true;
    }
    return false;
  }

  public void listVehicleStock() {
    for (Vehicle vehicle : vehicleStock) {
      System.out.println(vehicle.getType() + " with brand:" + vehicle.getBrand());
    }
  }

  public void listSoldCars() {
    float totalSold = 0;
    for (SoldItem<Vehicle> vehicle : soldVehicles) {
      totalSold += vehicle.getPrice();
      System.out.println("-------------------");
      System.out.println("Type:" + vehicle.getItem().getType() + " Brand:" + vehicle.getItem().getBrand() + "\nPrice:" + vehicle.getPrice());
    }
    System.out.println("---------------------------------------------");
    System.out.println("Total value sold:" + totalSold + "€");
  }

  public List<Vehicle> getCarStockList() {
    return vehicleStock;
  }
}
