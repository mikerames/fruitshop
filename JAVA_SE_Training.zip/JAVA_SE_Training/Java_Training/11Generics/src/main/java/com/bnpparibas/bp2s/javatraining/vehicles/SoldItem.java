package com.bnpparibas.bp2s.javatraining.vehicles;


public class SoldItem<T> {
  private T item;
  private float price;

  public SoldItem(T item, float price) {
    this.setItem(item);
    this.setPrice(price);
  }

  public T getItem() {
    return item;
  }

  public void setItem(T vehicle) {
    this.item = vehicle;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

}
