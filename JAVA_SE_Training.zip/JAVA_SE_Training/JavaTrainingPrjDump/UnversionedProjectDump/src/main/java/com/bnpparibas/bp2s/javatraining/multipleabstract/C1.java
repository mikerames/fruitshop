package com.bnpparibas.bp2s.javatraining.multipleabstract;

import com.bnpparibas.bp2s.javatraining.multipleabstract.A1;

public class C1 extends A1 {

  void hello() {
    System.out.println("hello c1");
  }
}
