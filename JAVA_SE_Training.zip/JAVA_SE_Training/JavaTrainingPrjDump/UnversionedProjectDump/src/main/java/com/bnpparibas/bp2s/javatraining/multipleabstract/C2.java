package com.bnpparibas.bp2s.javatraining.multipleabstract;

import com.bnpparibas.bp2s.javatraining.multipleabstract.A2;

public class C2 extends A2 {

  void hello() {
    System.out.println("Hello C2");
  }
}
