package com.bnpparibas.bp2s.javatraining.exceptions;


public class Main {

  public static void main(String[] args) throws Exception {
    throw new Exception("Blah!!");
  }

}
