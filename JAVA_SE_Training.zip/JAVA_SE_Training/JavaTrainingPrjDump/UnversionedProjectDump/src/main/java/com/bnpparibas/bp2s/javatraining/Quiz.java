package com.bnpparibas.bp2s.javatraining;

import java.util.LinkedList;
import java.util.List;

public class Quiz {

  private static void main(String[] args) {



  }

  private List<String> append(String value) {
    List<String> list2 = new LinkedList<>();
    list2.add("Hello");
    return list2;
  }

  private LinkedList<String> append2(String value) {
    LinkedList<String> list = new LinkedList<>();
    list.add("Hello");

    return list;
  }
}
