package com.bnpparibas.bp2s.javatraining.anonymous;


public class ConcreteBlah implements Blah {
  @Override
  public void doSomething() {
    throw new RuntimeException("Buh");
  }
}
