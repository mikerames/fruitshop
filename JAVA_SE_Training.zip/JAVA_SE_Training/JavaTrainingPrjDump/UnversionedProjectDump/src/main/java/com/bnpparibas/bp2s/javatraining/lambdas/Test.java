package com.bnpparibas.bp2s.javatraining.lambdas;

import java.util.Arrays;
import java.util.Comparator;

public class Test {
  public static void main(String[] args) {

    // Before Java 8...
    String[] values = new String[] {"C", "A", "B"};
    Arrays.sort(values, new Comparator<String>() {
      @Override
      public int compare(String o1, String o2) {
        return o1.charAt(0) - o2.charAt(0);
      }
    });
    System.out.println(Arrays.toString(values));

    // After Java 8...
    values = new String[] {"C", "A", "B", "Z", "D", "A", "Q", "W"};
    Arrays.sort(values, (s1, s2) -> s1.charAt(0) - s2.charAt(0));
    System.out.println(Arrays.toString(values));
  }
}
