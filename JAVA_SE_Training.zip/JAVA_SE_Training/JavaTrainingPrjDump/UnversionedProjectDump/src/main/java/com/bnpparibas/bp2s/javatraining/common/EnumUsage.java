package com.bnpparibas.bp2s.javatraining.common;

public class EnumUsage {
  public static void main(String[] args) {
    Operation result = Operation.HELLO;
    switch (result) {
      case ADD:
        System.out.println(result.getSign());
        break;
      default:
        System.out.println("unsupported");
    }
  }
}
