package com.bnpparibas.bp2s.javatraining.common;

public enum Operation {
  ADD("+"), SUBTRACT("-"), DIVIDE("/"), MULTIPLY("*"), HELLO("H");

  private final String sign;

  private Operation(String sign) {
    this.sign = sign;
  }

  public String getSign() {
    return sign;
  }

}
