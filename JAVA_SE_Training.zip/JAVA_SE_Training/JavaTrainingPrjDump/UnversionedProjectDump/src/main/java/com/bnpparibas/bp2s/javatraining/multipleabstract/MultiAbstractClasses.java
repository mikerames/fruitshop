package com.bnpparibas.bp2s.javatraining.multipleabstract;


public class MultiAbstractClasses {

  public static void main(String[] args) {
    A1 instance = new C2();
    instance.hello();
    instance = new C1();
    instance.hello();

  }

}
