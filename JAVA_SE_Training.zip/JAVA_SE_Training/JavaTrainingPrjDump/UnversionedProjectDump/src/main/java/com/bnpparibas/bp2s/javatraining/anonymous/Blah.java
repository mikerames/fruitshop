package com.bnpparibas.bp2s.javatraining.anonymous;

@FunctionalInterface
public interface Blah {
  void doSomething();
}
