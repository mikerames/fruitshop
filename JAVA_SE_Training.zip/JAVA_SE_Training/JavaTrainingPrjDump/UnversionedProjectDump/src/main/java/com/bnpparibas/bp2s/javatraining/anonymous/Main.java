package com.bnpparibas.bp2s.javatraining.anonymous;

public class Main {

  public static void main(String[] args) {
    Blah instance = new Blah() {
      @Override
      public void doSomething() {
        throw new RuntimeException("Buh");
      }
    };

    instance.doSomething();

    Blah instance2 = new ConcreteBlah();
    instance2.doSomething();


  }

}
