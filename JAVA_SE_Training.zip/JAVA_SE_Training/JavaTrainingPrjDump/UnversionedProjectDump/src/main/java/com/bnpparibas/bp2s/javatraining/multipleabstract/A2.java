package com.bnpparibas.bp2s.javatraining.multipleabstract;

import com.bnpparibas.bp2s.javatraining.multipleabstract.C1;

public abstract class A2 extends C1 {

  abstract void hello();
}
