package com.bnpparibas.bp2s.javatraining.list;



public class Main {
  public static void main(String args[]) {
    MarkedList<String> testList = new ReadedList<String>();
    System.out.println("Added Hello successfully? " + testList.add("Hello"));
    System.out.println("Readed? " + testList.isReaded(0));
    System.out.println("Get: " + testList.get(0));
    System.out.println("Readed? " + testList.isReaded(0));
  }
}
