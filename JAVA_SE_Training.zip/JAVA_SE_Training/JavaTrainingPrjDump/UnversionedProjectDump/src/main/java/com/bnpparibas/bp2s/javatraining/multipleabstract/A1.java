package com.bnpparibas.bp2s.javatraining.multipleabstract;

public abstract class A1 {

  abstract void hello();
}
